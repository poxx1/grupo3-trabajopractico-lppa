# LPPA-Grupo3-2021
UAI - Lenguajes de Programacion para la Administracion

Grupo 3 - Proyecto de E-Commerce

Integrantes del Grupo:

+ Aguilar, Franco
+ Andino, Cristian Ariel
+ Lastra, Julian Marcos
+ Lezcano, Mauro
+ Scale, David Emanuel
